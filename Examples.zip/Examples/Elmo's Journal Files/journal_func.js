function elmoPsyche() {
    alert("Teheee :)! You'll have to subscribe to see more of Elmo");
}